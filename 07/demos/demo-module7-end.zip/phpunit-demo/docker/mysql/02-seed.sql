INSERT INTO `product` (`id`, `name`, `cost`, `markup`)
VALUES (1, 'Concert 1', 1000, 10),
       (2, 'Concert 2', 500, 10);
