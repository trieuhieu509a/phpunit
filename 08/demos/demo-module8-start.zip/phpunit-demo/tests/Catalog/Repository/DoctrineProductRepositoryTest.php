<?php
declare(strict_types=1);

namespace App\Catalog\Repository;

use PHPUnit\Framework\TestCase;

/** @covers \App\Catalog\Repository\DoctrineProductRepository */
final class DoctrineProductRepositoryTest extends TestCase
{
}
