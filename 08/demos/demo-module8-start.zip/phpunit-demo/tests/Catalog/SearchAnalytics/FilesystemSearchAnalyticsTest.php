<?php
declare(strict_types=1);

namespace App\Tests\Catalog\SearchAnalytics;

use App\Tests\IntegrationTestCase;

/** @covers \App\Catalog\SearchAnalytics\FilesystemSearchAnalytics */
final class FilesystemSearchAnalyticsTest extends IntegrationTestCase
{
}
